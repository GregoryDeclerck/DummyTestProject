package com.squoring.squore.test;

public class Main {
	public static void main(String[] args) {
		System.out.println("Hello Squore ! What is my SquOre ?");
	}
}
